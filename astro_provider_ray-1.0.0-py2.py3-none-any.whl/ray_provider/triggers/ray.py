from __future__ import annotations
import asyncio
from typing import Any, AsyncIterator
from functools import cached_property
from airflow.triggers.base import BaseTrigger, TriggerEvent
from ray.job_submission import JobStatus
from ray_provider.hooks.ray import RayHook

class RayJobTrigger(BaseTrigger):
    """
    Triggers and monitors the status of a Ray job.

    This trigger periodically checks the status of a submitted job on a Ray cluster and
    yields events based on the job's status. It handles timeouts and errors during
    the polling process.

    :param job_id: Required. The unique identifier of the Ray job.
    :param conn_id: Required. The connection ID for the Ray cluster.
    :param poll_interval: Optional. The interval in seconds at which to poll the job status. Defaults to 30 seconds.

    :raises AirflowException: If no job_id is provided or an error occurs during polling.
    """

    def __init__(self, job_id: str, conn_id: str, xcom_dashboard_url: str | None, poll_interval: int = 30):
        super().__init__()
        self.job_id = job_id
        self.conn_id = conn_id
        self.dashboard_url = xcom_dashboard_url
        self.poll_interval = poll_interval

    def serialize(self) -> tuple[str, dict[str, Any]]:
        return (
            "ray_provider.triggers.ray.RayJobTrigger",
            {"job_id": self.job_id,
             "conn_id": self.conn_id,
             "xcom_dashboard_url": self.dashboard_url,
             "poll_interval": self.poll_interval},
        )

    @cached_property
    def hook(self) -> RayHook:
        return RayHook(conn_id=self.conn_id,
                       xcom_dashboard_url=self.dashboard_url)

    async def run(self) -> AsyncIterator[TriggerEvent]:
        if not self.job_id:
            yield TriggerEvent(
                {"status": "error", "message": "No job_id provided to async trigger"}
            )
            return

        try:
            self.log.info(f"Polling for job {self.job_id} every {self.poll_interval} seconds...")

            while not self._is_terminal_state():
                await asyncio.sleep(self.poll_interval)

            # Stream logs if available
            async for multi_line in self.hook.get_tail_logs(self.job_id):
                self.log.info(multi_line)

            self.log.info(f"Job {self.job_id} completed execution before the timeout period...")

            completed_status = self._get_current_status()
            self.log.info(f"Status of completed job {self.job_id} is: {completed_status}")
            if completed_status == JobStatus.SUCCEEDED:
                yield TriggerEvent(
                    {
                        "status": "success",
                        "message": f"Job run {self.job_id} has completed successfully.",
                        "job_id": self.job_id,
                    }
                )
            elif completed_status == JobStatus.STOPPED:
                yield TriggerEvent(
                    {
                        "status": "cancelled",
                        "message": f"Job run {self.job_id} has been stopped.",
                        "job_id": self.job_id,
                    }
                )
            else:
                yield TriggerEvent(
                    {
                        "status": "error",
                        "message": f"Job run {self.job_id} has failed.",
                        "job_id": self.job_id,
                    }
                )
        except Exception as e:
            yield TriggerEvent({"status": "error", "message": str(e), "job_id": self.job_id})

    def _get_current_status(self) -> str:
        job_status = self.hook.get_job_status(self.job_id)
        self.log.info(f"Current job status for {self.job_id} is: {job_status}")
        return job_status
    
    def _is_terminal_state(self) -> bool:
        return self._get_current_status() in (JobStatus.SUCCEEDED, JobStatus.STOPPED, JobStatus.FAILED)