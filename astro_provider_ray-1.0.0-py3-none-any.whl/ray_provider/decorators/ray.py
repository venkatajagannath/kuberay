from __future__ import annotations

from typing import Any, Callable

import ray
from airflow.decorators.base import DecoratedOperator, TaskDecorator, task_decorator_factory
from airflow.exceptions import AirflowException
from airflow.utils.context import Context

from ray_provider.hooks.ray import RayHook


class _RayDecoratedOperator(DecoratedOperator):
    """
    A custom Airflow operator for Ray tasks.

    This operator allows users to define tasks that execute code on a Ray cluster.

    :param config: Configuration dictionary for the Ray job.
    :param kwargs: Additional keyword arguments.
    """

    custom_operator_name = "@task.ray"

    template_fields: Any = DecoratedOperator.template_fields

    def __init__(self, config: dict[str, Any], **kwargs: Any) -> None:
        self.conn_id: str = config.get("conn_id", "ray_default")
        self.ray_init_params: dict[str, Any] = {k: v for k, v in config.items() if k != "conn_id"}
        super().__init__(**kwargs)

    def execute(self, context: Context) -> Any:
        """
        Execute the Ray task.

        :param context: The context in which the task is being executed.
        :return: The result of the Ray job execution.
        :raises AirflowException: If job execution fails or if Ray cluster address is not available.
        """
        ray_hook = RayHook(conn_id=self.conn_id)

        # Use the address from the hook if not provided in ray_init_params
        if "address" not in self.ray_init_params:
            if not ray_hook.address:
                raise AirflowException("Ray cluster address is not available from the hook or task configuration")
            self.ray_init_params["address"] = ray_hook.address

        self.log.info(f"Connecting to Ray cluster at {self.ray_init_params['address']}...")
        try:
            ray.init(**self.ray_init_params)
            self.log.info("Successfully connected to Ray cluster")

            self.log.info("Executing Ray task...")
            result = self.python_callable(*self.op_args, **self.op_kwargs)
            self.log.info("Ray task execution completed")
            return result

        except Exception as e:
            self.log.error(f"Error during Ray task execution: {e}")
            raise AirflowException("Ray task execution failed") from e
        finally:
            ray.shutdown()


def ray_task(
    python_callable: Callable[..., Any] | None = None,
    multiple_outputs: bool | None = None,
    **kwargs: Any,
) -> TaskDecorator:
    """
    Decorator to define a task that executes on a Ray cluster.

    :param python_callable: The callable function to decorate.
    :param multiple_outputs: If True, will return multiple outputs.
    :param kwargs: Additional keyword arguments.
    :return: The decorated task.
    """
    return task_decorator_factory(
        python_callable=python_callable,
        multiple_outputs=multiple_outputs,
        decorated_operator_class=_RayDecoratedOperator,
        **kwargs,
    )
