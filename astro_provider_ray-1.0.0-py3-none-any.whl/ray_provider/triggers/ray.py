from __future__ import annotations

import asyncio
from functools import cached_property, partial
from typing import Any, AsyncIterator, Iterator

from airflow.triggers.base import BaseTrigger, TriggerEvent
from ray.job_submission import JobStatus

from ray_provider.hooks.ray import RayHook


class RayJobTrigger(BaseTrigger):
    """
    Triggers and monitors the status of a Ray job.

    This trigger periodically checks the status of a submitted job on a Ray cluster and
    yields events based on the job's status. It handles timeouts and errors during
    the polling process.

    :param job_id: The unique identifier of the Ray job.
    :param conn_id: The connection ID for the Ray cluster.
    :param xcom_dashboard_url: Optional URL for the Ray dashboard.
    :param poll_interval: The interval in seconds at which to poll the job status. Defaults to 30 seconds.
    """

    def __init__(
        self,
        job_id: str,
        conn_id: str,
        xcom_dashboard_url: str | None,
        poll_interval: int = 30,
        fetch_logs: bool = True,
    ):
        super().__init__()  # type: ignore[no-untyped-call]
        self.job_id = job_id
        self.conn_id = conn_id
        self.dashboard_url = xcom_dashboard_url
        self.fetch_logs = fetch_logs
        self.poll_interval = poll_interval
        self.log_iterator: AsyncIterator[str] | None = None

    def serialize(self) -> tuple[str, dict[str, Any]]:
        """
        Serializes the trigger's configuration.

        :return: A tuple containing the fully qualified class name and a dictionary of its parameters.
        """
        return (
            "ray_provider.triggers.ray.RayJobTrigger",
            {
                "job_id": self.job_id,
                "conn_id": self.conn_id,
                "xcom_dashboard_url": self.dashboard_url,
                "fetch_logs": self.fetch_logs,
                "poll_interval": self.poll_interval,
            },
        )

    @cached_property
    def hook(self) -> RayHook:
        """
        Lazily initializes and returns a RayHook instance.

        :return: An instance of RayHook configured with the connection ID and dashboard URL.
        """
        return RayHook(conn_id=self.conn_id, xcom_dashboard_url=self.dashboard_url)

    async def run(self) -> AsyncIterator[TriggerEvent]:
        """
        Asynchronously polls the job status and yields events based on the job's state.

        This method gets job status at each poll interval and streams logs if available.
        It yields a TriggerEvent upon job completion, cancellation, or failure.

        :yield: TriggerEvent containing the status, message, and job ID related to the job.
        """
        try:
            self.log.info(f"Polling for job {self.job_id} every {self.poll_interval} seconds...")

            while not self._is_terminal_state():

                # Check for new log lines
                self.log.info(f"Fetch logs flag is set to : {self.fetch_logs}")
                if self.fetch_logs:
                    # Stream logs if available
                    self.log.info(f"::group::{self.job_id} logs")
                    await self._get_logs()
                    self.log.info("::endgroup::")

                await asyncio.sleep(self.poll_interval)

            completed_status = self.hook.get_ray_job_status(self.job_id)
            self.log.info(f"Status of completed job {self.job_id} is: {completed_status}")
            yield TriggerEvent(
                {
                    "status": completed_status,
                    "message": f"Job {self.job_id} completed with status {completed_status}",
                    "job_id": self.job_id,
                }
            )
        except Exception as e:
            yield TriggerEvent({"status": str(JobStatus.FAILED), "message": str(e), "job_id": self.job_id})

    @staticmethod
    def extract_message(log_line: str) -> str:
        parts = log_line.split(" -- ", 1)
        return parts[1] if len(parts) > 1 else log_line

    async def _get_logs(self):
        if self.log_iterator is None:
            self.log_iterator = self.hook.get_ray_tail_logs(self.job_id)
        
        async for log in self.log_iterator:
            message = self.extract_message(log)
            self.log.info(message)

    def _is_terminal_state(self) -> bool:
        """
        Checks if the Ray job is in a terminal state.

        A terminal state is one of the following: SUCCEEDED, STOPPED, or FAILED.

        :return: True if the job is in a terminal state, False otherwise.
        """
        return self.hook.get_ray_job_status(self.job_id) in (JobStatus.SUCCEEDED, JobStatus.STOPPED, JobStatus.FAILED)
